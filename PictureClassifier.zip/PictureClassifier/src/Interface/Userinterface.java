package Interface;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Timer;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.Dialog.ModalExclusionType;
import java.awt.Dimension;

import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.Label;
import java.awt.Rectangle;
import java.awt.TextArea;

import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.plaf.ProgressBarUI;
import javax.tools.Tool;
import javax.xml.stream.events.StartDocument;

import Algorithm.ReadFile;

import javax.swing.JTextPane;
import javax.swing.JProgressBar;
import javax.swing.JCheckBox;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class Userinterface extends JFrame implements ActionListener {
	private JTextField txtSourceDirectory;
	private JButton btnChooseDirectory;
	final JTextArea textArea = new JTextArea();
	public static int PicNum=0;   //ԴĿ¼�����jpgͼƬ��
	public static int DoneNum=0;  //�Ѿ�������ɵ�jpgͼƬ��
	public static String str="";  //������ļ��е��ַ���
	static String srcfilepath;
	static String aimfilepath;
	private JTextField txtTargetDirectory;
	final ReadFile readFile = new ReadFile();
	ReadFile readFile1 = new ReadFile();
	//Thread thread1 = null;
	Thread thread2 = null;


	public Userinterface(){

		super("PictureClassifier");
		setTitle("\u56FE\u7247\u5F52\u7C7B\u5668");
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (InstantiationException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (IllegalAccessException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		} catch (UnsupportedLookAndFeelException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		//ImageIcon imageIcon = new ImageIcon(getClass().getResource("\\1.png"));  // ���ñ�������ͼ��Ϊ1.png
		//this.setIconImage(imageIcon.getImage());


		final JProgressBar progressBar = new JProgressBar();
		progressBar.setForeground(Color.GRAY);
		progressBar.setToolTipText("������");
		progressBar.setBounds(14, 269, 307, 24);
		getContentPane().add(progressBar);
		progressBar.setStringPainted(true);


		this.setResizable(false);
		this.setSize(473, 457);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		getContentPane().setLayout(null);



		txtSourceDirectory = new JTextField();
		txtSourceDirectory.setFont(new Font("������", Font.PLAIN, 16));
		txtSourceDirectory.setHorizontalAlignment(SwingConstants.CENTER);
		txtSourceDirectory.setText("\u6E90\u76EE\u5F55");
		txtSourceDirectory.setEditable(false);
		txtSourceDirectory.setColumns(10);
		txtSourceDirectory.setBounds(14, 305, 307, 24);
		getContentPane().add(txtSourceDirectory);






		btnChooseDirectory = new JButton("\u9009\u62E9\u6587\u4EF6");
		btnChooseDirectory.setVerticalAlignment(SwingConstants.TOP);
		btnChooseDirectory.setFont(new Font("������", Font.PLAIN, 17));
		btnChooseDirectory.setToolTipText("ֻ��ѡ��Ŀ¼!");
		btnChooseDirectory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				srcfilepath=null;
				JFileChooser jFileChooser = new JFileChooser();
				jFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);//����ֻ��ѡ��Ŀ¼
				jFileChooser.setCurrentDirectory(new File("C:\\Users\\��è��ѵ����\\Desktop"));//�ļ�ѡ�����ĳ�ʼĿ¼��ΪC��
				jFileChooser.showOpenDialog(null);
				if(jFileChooser.getSelectedFile()!=null){
					srcfilepath = jFileChooser.getSelectedFile().getAbsolutePath();
					if(!srcfilepath.endsWith("\\")){
						txtSourceDirectory.setText(srcfilepath);
					}
					else {
						JOptionPane.showMessageDialog(null, "ԴĿ¼ѡ��ʧ�ܣ�", "����", JOptionPane.ERROR_MESSAGE );

						return;
					}

					try {

						String string = readFile1.listfile(srcfilepath);					
						PicNum=readFile1.getPicNum();
						if(PicNum==0)
							textArea.setText(string+"ԴĿ¼��û��ͼƬ��");
						else if (PicNum==1)
							textArea.setText(string+"ԴĿ¼�н��� "+PicNum+" ��ͼƬ��");			
						else 
							textArea.setText(string+"ԴĿ¼���� "+PicNum+" ��ͼƬ��");

						JOptionPane.showMessageDialog(null, "ԴĿ¼ѡ��ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE );
						readFile1.clearStr(); //����ϴ�ѡ���ԴĿ¼�ַ���
						readFile1.clearPicNum(); //����ϴ�ѡ��Ŀ¼��ͼƬ����


					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				else {
					txtSourceDirectory.setText("");
					JOptionPane.showMessageDialog(null, "ԴĿ¼ѡ��ʧ�ܣ�", "����", JOptionPane.ERROR_MESSAGE );

					return;
				}
			}			
		});






		btnChooseDirectory.setBounds(335, 304, 120, 27);
		getContentPane().add(btnChooseDirectory);

		final JButton btnOr = new JButton("\u590D\u5236");
		btnOr.setFont(new Font("����", Font.PLAIN, 20));
		btnOr.setBounds(14, 375, 441, 38);
		btnOr.setToolTipText("");
		getContentPane().add(btnOr);



		JScrollPane jsp = new JScrollPane();
		jsp.setBounds(14, 13, 440, 242);

		jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

		getContentPane().add(jsp);
		textArea.setForeground(Color.BLACK);
		jsp.setViewportView(textArea);
		textArea.setEditable(false);
		textArea.setToolTipText("ԴĿ¼��Ϣ");
		textArea.setFont(new Font("������", Font.PLAIN, 16));
		//lblAllPicturesIn.setToolTipText("ԴĿ¼�е�����ͼƬ��");

		final JButton btnChoose = new JButton("\u9009\u62E9\u6587\u4EF6");
		btnChoose.setVerticalAlignment(SwingConstants.TOP);
		btnChoose.setFont(new Font("������", Font.PLAIN, 17));
		btnChoose.setToolTipText("ֻ��ѡ��Ŀ¼!");
		btnChoose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtTargetDirectory.setText("");
				JFileChooser jFileChooser = new JFileChooser();
				jFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);//����ֻ��ѡ��Ŀ¼
				jFileChooser.setCurrentDirectory(new File("C:\\Users\\��è��ѵ����\\Desktop"));//�ļ�ѡ�����ĳ�ʼĿ¼��ΪC��
				jFileChooser.showOpenDialog(null);

				if(jFileChooser.getSelectedFile()!=null){
					aimfilepath = jFileChooser.getSelectedFile().getAbsolutePath();
					txtTargetDirectory.setText(aimfilepath);

					JOptionPane.showMessageDialog(null, "Ŀ��Ŀ¼ѡ��ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE );
				}
				else {
					txtTargetDirectory.setText("");
					JOptionPane.showMessageDialog(null, "Ŀ��Ŀ¼ѡ��ʧ�ܣ�", "����", JOptionPane.ERROR_MESSAGE );
					return;
				}			
			}
		});





		btnChoose.setBounds(335, 340, 120, 27);
		getContentPane().add(btnChoose);

		txtTargetDirectory = new JTextField();
		txtTargetDirectory.setFont(new Font("������", Font.PLAIN, 16));
		txtTargetDirectory.setText("\u76EE\u6807\u76EE\u5F55");
		txtTargetDirectory.setHorizontalAlignment(SwingConstants.CENTER);
		txtTargetDirectory.setEditable(false);
		txtTargetDirectory.setColumns(10);
		txtTargetDirectory.setBounds(14, 341, 307, 24);
		getContentPane().add(txtTargetDirectory);

		final JCheckBox chckbxNewCheckBox = new JCheckBox("\u81EA\u52A8\u66F4\u65B0");
		chckbxNewCheckBox.setFont(new Font("������", Font.PLAIN, 17));
		chckbxNewCheckBox.setBounds(332, 266, 123, 27);
		chckbxNewCheckBox.setToolTipText("ÿ��2���Ӹ���һ�Σ�");
		getContentPane().add(chckbxNewCheckBox);





		chckbxNewCheckBox.addActionListener(new ActionListener(){ //���帴ѡ�򴥷��¼�

			public void actionPerformed(ActionEvent e){



				if(chckbxNewCheckBox.isSelected() && srcfilepath!=null && aimfilepath!=null){

					JOptionPane.showMessageDialog(null, "���Զ����£�", "��ʾ", JOptionPane.INFORMATION_MESSAGE );
					btnOr.setEnabled(false);
					btnChoose.setEnabled(false);
					btnChooseDirectory.setEnabled(false);

					thread2 = new Thread(){

						public void run(){
							for(;;){
								if(!chckbxNewCheckBox.isSelected()){
									return;
								}
								if (chckbxNewCheckBox.isSelected() && srcfilepath!=null && aimfilepath!=null){
									try {
										SwingUtilities.invokeLater(new Runnable() {
											public void run() {

												for (int i = 0;i!=PicNum;) {


													i=readFile.getDoneNum();

													Dimension d = progressBar.getSize();
													Rectangle rect = new Rectangle(0,0, d.width, d.height);
													progressBar.setValue(i*100/PicNum); // ���ý�������ֵ 
													progressBar.paintImmediately(rect);	// ���ľ������Ϊ�˷�ֹ����������ʹ�ý���������ʾ����						
												}
												progressBar.setValue(0);
											}
										});			
										ReadFile readFile3 = new ReadFile();
										String string = readFile3.listfile(srcfilepath);
										PicNum=readFile3.getPicNum();
										if(PicNum==0)
											textArea.setText(string+"ԴĿ¼��û��ͼƬ��");
										else if (PicNum==1)
											textArea.setText(string+"ԴĿ¼�н��� "+PicNum+" ��ͼƬ��");			
										else 
											textArea.setText(string+"ԴĿ¼���� "+PicNum+" ��ͼƬ��");

										readFile.readfile(srcfilepath, aimfilepath);  //����Ҳ��������ִ��һ��ͼƬ���Ʋ���		
										JOptionPane.showMessageDialog(null, "���³ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE );
										readFile.setDoneNum(0); //�����ͼƬ����0
										readFile3.clearStr(); //����ϴ�ѡ���ԴĿ¼�ַ���
										readFile3.clearPicNum(); //����ϴ�ѡ��Ŀ¼��ͼƬ����
										Thread.sleep(1000*120); //�ȸ���һ�Σ���ÿ��2���Ӹ���һ��,���ǵ���ͼƬ�������ʱ�����ֵ���Զ���ĸ���Щ
										
									} catch (IOException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									} catch (InterruptedException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}
								else {
									JOptionPane.showMessageDialog(null, "����ʧ�ܣ�", "����", JOptionPane.ERROR_MESSAGE );
									return;
								}
							}
						}
					};
					thread2.start();
					return;
				}

				if(chckbxNewCheckBox.isSelected()){
					if(srcfilepath == null){
						JOptionPane.showMessageDialog(null, "ԴĿ¼����Ϊ�գ�", "��ʾ", JOptionPane.ERROR_MESSAGE );
						chckbxNewCheckBox.setSelected(false);
						return;
					}
					if(aimfilepath == null){
						JOptionPane.showMessageDialog(null, "Ŀ��Ŀ¼����Ϊ�գ�", "��ʾ", JOptionPane.ERROR_MESSAGE );
						chckbxNewCheckBox.setSelected(false);
						return;
					}
				}
				else if(!chckbxNewCheckBox.isSelected()){
					JOptionPane.showMessageDialog(null, "�ر��Զ����£�", "��ʾ", JOptionPane.INFORMATION_MESSAGE );
					btnOr.setEnabled(true);
					btnChoose.setEnabled(true);
					btnChooseDirectory.setEnabled(true);
					thread2.stop();
					return;
				}
				//thread1.interrupt();
			}
		});






		btnOr.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if(srcfilepath!=null && aimfilepath!=null){

					Thread thread3 = new Thread() {
						public void run() {				
							for (int i = 0;i!=PicNum;) {
								/*try {
									Thread.sleep(2);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}*/

								i=readFile.getDoneNum();

								Dimension d = progressBar.getSize();
								Rectangle rect = new Rectangle(0,0, d.width, d.height);
								progressBar.setValue(i*100/PicNum); // ���ý�������ֵ 
								progressBar.paintImmediately(rect);	// ���ľ������Ϊ�˷�ֹ����������ʹ�ý���������ʾ����						
							}
							progressBar.setValue(0);
						}
					};

					thread3.start();

					try {

						ReadFile readFile2 = new ReadFile();
						String string = readFile2.listfile(srcfilepath);
						PicNum=readFile2.getPicNum();
						if(PicNum==0)
							textArea.setText(string+"ԴĿ¼��û��ͼƬ��");
						else if (PicNum==1)
							textArea.setText(string+"ԴĿ¼�н��� "+PicNum+" ��ͼƬ��");			
						else 
							textArea.setText(string+"ԴĿ¼���� "+PicNum+" ��ͼƬ��");

						readFile.readfile(srcfilepath, aimfilepath);
						JOptionPane.showMessageDialog(null, "���Ƴɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE );
						readFile.setDoneNum(0);  //������ɵ�ͼƬ�����㣬�Ա���Զ��ִ��

						readFile2.clearPicNum();
						readFile2.clearStr();

					} catch (IOException e1) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(null, "����ʧ�ܣ�", "����", JOptionPane.ERROR_MESSAGE );
						e1.printStackTrace();
					}

					thread3.interrupt();


				}


				else {
					JOptionPane.showMessageDialog(null, "ԴĿ¼��Ŀ��Ŀ¼����Ϊ�գ�", "����", JOptionPane.ERROR_MESSAGE );
					return;
				}

			}
		});
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Userinterface().setVisible(true); //���������߳���ʾ������   
	}

	public void actionPerformed(ActionEvent e) {

	}
}